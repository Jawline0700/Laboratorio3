<?php
class logica{
    private $host = "localhost";
    private $db= "laboratorio3";
    private $user= "admin";
    private $pass ="123456";
    public $conn;

    public function __construct(){
      $this->conn= new PDO("mysql:host=".$this->host.";dbname=".$this->db,$this->user,$this->pass);
    }

    public function tipousuario(){
      try
		{
			$result = array();
			$stm = $this->conn->prepare('SELECT * FROM nivel');
			$stm->execute();
			return $stm->fetchAll(PDO::FETCH_OBJ);
		}
		catch(Exception $e)
		{
			die($e->getMessage());
		}
        
    }


    public function provincia(){
      try
		{
			$result = array();
			$stm = $this->conn->prepare('SELECT * FROM provincia');
			$stm->execute();
			return $stm->fetchAll(PDO::FETCH_OBJ);
		}
		catch(Exception $e)
		{
			die($e->getMessage());
		}
        
    }

	public function usuario($nombre,$apellido,$email,$password,$id_nivel,$id_distrito,$telefono){

		try{
			$data =['nombre'=>$nombre,'apellido'=>$apellido,'email'=>$email,'password'=>$password,'id_nivel'=>$id_nivel,'id_distrito'=>$id_distrito,'telefono'=>$telefono];
            $sql = "INSERT INTO usuario (nombre,apellido,email,password,id_nivel,id_distrito,telefono) VALUES(:nombre,:apellido,:email,:password,:id_nivel,:id_distrito,:telefono)";
			$stmt = $this->conn->prepare($sql);
			$stmt->execute($data);
			echo("Se inserto con exito");
         header( "refresh:1;../index.php");

		}catch(PDOException $e){
			echo "Error";
	} 

	}


    
    public function distrito($id){
      try
		{
			$result = array();
			$stm = $this->conn->prepare('SELECT * FROM distrito WHERE id_provincia='.$id);
			$stm->execute();
			return $stm->fetchAll(PDO::FETCH_OBJ);
		}
		catch(Exception $e)
		{
			die($e->getMessage());
		}
        
    }

	public function selectall(){
		try
		{
			$result = array();
			$stm = $this->conn->prepare('SELECT usuario.id_usuario,usuario.nombre,usuario.apellido,usuario.telefono,usuario.email,distrito.nom_distrito,nivel.nom_nivel, provincia.nom_provincia from usuario join distrito on distrito.id_distrito = usuario.id_distrito join nivel on nivel.id_nivel=usuario.id_nivel join provincia ON provincia.id_provincia = distrito.id_provincia');
			$stm->execute();
			return $stm->fetchAll(PDO::FETCH_OBJ);
		}
		catch(Exception $e)
		{
			die($e->getMessage());
		}

	}

}

?>