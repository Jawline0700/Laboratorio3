<?php

require('logica.php');
$id = $_POST['id'];
$user = new logica();
$resultado = $user->distrito($id);
$html= " ";
if(!$resultado){
    die("Query failed:".mysql_error());
}
else
{    foreach ($resultado as $value){

	
		$html.="<option value='".$value->id_distrito."'>".$value->nom_distrito."</option>";
	echo $html;	
 }
}



?>