<?php
require('logica.php');
$user=new logica();
$nombre =$_REQUEST['name'];
$apellido =$_REQUEST['lastname'];
$correo =$_REQUEST['email'];
$contra =$_REQUEST['pass'];
$telefono =$_REQUEST['telefono'];
$tipousuario =$_REQUEST['usuario'];
$provincia =$_REQUEST['provincia'];
$distrito =$_REQUEST['results'];

$user->usuario($nombre,$apellido,$correo,$contra,$tipousuario,$distrito,$telefono);


?>