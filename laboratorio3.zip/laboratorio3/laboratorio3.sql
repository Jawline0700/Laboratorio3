-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 14-11-2021 a las 00:51:12
-- Versión del servidor: 10.4.20-MariaDB
-- Versión de PHP: 8.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `laboratorio3`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `distrito`
--

CREATE TABLE `distrito` (
  `id_distrito` int(11) NOT NULL,
  `nom_distrito` varchar(100) NOT NULL,
  `id_provincia` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `distrito`
--

INSERT INTO `distrito` (`id_distrito`, `nom_distrito`, `id_provincia`) VALUES
(1, 'Almirante', 1),
(2, 'Bocas Del Toro', 1),
(3, 'Changuinola', 1),
(4, 'Chiriquí Grande', 1),
(5, 'Aguadulce', 2),
(6, 'Antón', 2),
(7, 'La Pintada', 2),
(8, 'Natá', 2),
(9, 'Olá', 2),
(10, 'Penonomé', 2),
(11, 'Colón', 3),
(12, 'Chagres', 3),
(13, 'Donoso', 3),
(14, 'Omar Torrijos Herrera', 3),
(15, 'Portobelo', 3),
(16, 'Santa Isabel', 3),
(17, 'Alanje', 4),
(18, 'Barú', 4),
(19, 'Boquerón', 4),
(20, 'Boquete', 4),
(21, 'Bugaba', 4),
(22, 'David', 4),
(23, 'Dolega', 4),
(24, 'Gualaca', 4),
(25, 'Remedios', 4),
(26, 'San Felix', 4),
(27, 'San Lorenzo', 4),
(28, 'Tierras Altas', 4),
(29, 'Tolé', 4),
(30, 'Chepigana', 5),
(31, 'Santa Fe', 5),
(32, 'Pinogana', 5),
(33, 'Chitré', 6),
(34, 'Las Minas', 6),
(35, 'Los Pozos', 6),
(36, 'Ocú', 6),
(37, 'Parita', 6),
(38, 'Pesé', 6),
(39, 'Santa María', 6),
(40, 'Guararé', 7),
(41, 'Las Tablas', 7),
(42, 'Macaracas', 7),
(43, 'Pedasí', 7),
(44, 'Pocrí', 7),
(45, 'Tonosí', 7),
(46, 'Balboa', 8),
(47, 'Chepo', 8),
(48, 'Chimán', 8),
(49, 'Panamá', 8),
(50, 'San Miguelito', 8),
(51, 'Taboga', 8),
(52, 'Atalaya', 9),
(53, 'Calobre', 9),
(54, 'Cañazas', 9),
(55, 'Las Palmas', 9),
(56, 'Mariato', 9),
(57, 'Montijo', 9),
(58, 'Río de Jesús', 9),
(59, 'San Francisco', 9),
(60, 'Santa Fe', 9),
(61, 'Santiago', 9),
(62, 'Soná', 9),
(63, 'La Mesa', 9),
(64, 'La Mesa', 9),
(65, 'Arraijan', 13),
(66, 'Capira', 13),
(67, 'Chame', 13),
(68, 'La Chorrera', 13),
(69, 'San Carlos', 13);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `nivel`
--

CREATE TABLE `nivel` (
  `id_nivel` int(11) NOT NULL,
  `nom_nivel` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `nivel`
--

INSERT INTO `nivel` (`id_nivel`, `nom_nivel`) VALUES
(1, 'Estudiante'),
(2, 'Administrativo'),
(3, 'Docente');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `provincia`
--

CREATE TABLE `provincia` (
  `id_provincia` int(11) NOT NULL,
  `nom_provincia` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `provincia`
--

INSERT INTO `provincia` (`id_provincia`, `nom_provincia`) VALUES
(1, 'Bocas Del Toro'),
(2, 'Coclé'),
(3, 'Colón'),
(4, 'Chiriquí'),
(5, 'Darién'),
(6, 'Herrera'),
(7, 'Los Santos'),
(8, 'Panamá'),
(9, 'Veraguas'),
(13, 'Panama Oeste');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `id_usuario` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `apellido` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `id_nivel` int(11) NOT NULL,
  `id_distrito` int(11) NOT NULL,
  `telefono` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`id_usuario`, `nombre`, `apellido`, `email`, `password`, `id_nivel`, `id_distrito`, `telefono`) VALUES
(10, 'WENCERS', 'CASTILLO', 'mathewscastillo40@gmail.com', '123', 1, 69, '+50763194033');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `distrito`
--
ALTER TABLE `distrito`
  ADD PRIMARY KEY (`id_distrito`),
  ADD KEY `id_provincia` (`id_provincia`);

--
-- Indices de la tabla `nivel`
--
ALTER TABLE `nivel`
  ADD PRIMARY KEY (`id_nivel`);

--
-- Indices de la tabla `provincia`
--
ALTER TABLE `provincia`
  ADD PRIMARY KEY (`id_provincia`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id_usuario`),
  ADD KEY `id_nivel` (`id_nivel`),
  ADD KEY `id_distrito` (`id_distrito`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `distrito`
--
ALTER TABLE `distrito`
  MODIFY `id_distrito` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=70;

--
-- AUTO_INCREMENT de la tabla `nivel`
--
ALTER TABLE `nivel`
  MODIFY `id_nivel` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `provincia`
--
ALTER TABLE `provincia`
  MODIFY `id_provincia` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT de la tabla `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `distrito`
--
ALTER TABLE `distrito`
  ADD CONSTRAINT `Distrito_ibfk_1` FOREIGN KEY (`id_provincia`) REFERENCES `provincia` (`id_provincia`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD CONSTRAINT `Usuario_ibfk_1` FOREIGN KEY (`id_nivel`) REFERENCES `nivel` (`id_nivel`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `Usuario_ibfk_2` FOREIGN KEY (`id_distrito`) REFERENCES `distrito` (`id_distrito`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
