<?php 
//include('PHP/Conexion.php');
//$consultar = $conn->query('Select * from nivel');
require('PHP/logica.php');
$logica = new logica();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@0.9.3/css/bulma.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta2/css/all.min.css">
    <script src="jquery-3.6.0.min.js"></script>
    <title>Laboratorio#3</title>
</head>
<body>
<script>
function SelectedValue(sel) {
var value = sel.options[sel.selectedIndex].value;
console.log(value);
$.post( "PHP/distrito.php",{ id: value},
function(data){
$('#results').html(data);
});

}

</script>
 <section class = "hero is-info">
<div class ="hero-body"> 
<div class ="container has-text-centered">
<h1 class="title">Formulario</h1>
</div>
</div>
</section>
<section class ="section">
<div class ="container">
 <div class="columns">
<div class="column is-4-desktop is-offset-4-desktop">
<div class="content">
<h2 class="title is-4">Ingrese los Datos</h2>
<form class="form" action="PHP/insercion.php" method="POST" >
<div class="field is-horizontal">
<div class="field-body">
<div class="field">
<p class="control is-expanded has-icons-left">
<input class="input" type="text" placeholder="Nombre" required name="name">
<span class="icon is-small is-left">
<i class="fas fa-user"></i>
</span>
</p>
</div>
<div class="field">
<p class="control is-expanded has-icons-left">
<input class="input" type="text" placeholder="Apellido" required name="lastname">
<span class="icon is-small is-left">
<i class="fas fa-search"></i>
</span>
</p>
</div>
</div>
</div>
<div class="field is-horizontal">
<div class="field-body">
<div class="field is-expanded">
<p class="control is-expanded has-icons-left has-icons-right">
<input class="input is-success" type="email" placeholder="Email" required name="email">
<span class="icon is-small is-left">
  <i class="fas fa-envelope"></i>
    </span>
      <span class="icon is-small is-right">
  <i class="fas fa-check"></i>
</span>
</p>
</div>
</div>
</div>
<div class="field is-horizontal">
 <div class="field-body">
  <div class="field is-expanded">  
  <p class="control is-expanded has-icons-left has-icons-right">
  <input class="input" type="password" placeholder="Password" required name="pass">
  <span class="icon is-small is-left">
  <i class="fas fa-key"></i>
  </span>
  </p>
  </div>
  </div>
  </div>
  <div class="field is-horizontal">
  <div class="field-body">
  <div class="field is-expanded">
  <div class="field has-addons">
  <p class="control">
  <a class="button is-static">
  +507
  </a>
  </p>
   <p class="control is-expanded">
   <input class="input" type="tel" placeholder="Numero Telefono" required name="telefono">
   </p>
  </div>
  </div>
  </div>
  </div>

  <div class="field is-horizontal">
  <div class="field-body">
  <div class="field is-narrow">
  <div class="control">
  <div class="select">
  <select id="usuario" name="usuario" required>
  <?php $u=$logica->tipousuario();
  foreach($u as $ui){?>
  <option value="<?php echo $ui->id_nivel;?>"><?php echo $ui->nom_nivel;?></option>
  <?php } ?>
  </select>
  </div>
  </div>
  </div>
  </div>
  <div class="field-body">
  <div class="field is-narrow">
  <div class="control">
  <div class="select">
  <select id="provincia" name="provincia" onchange="SelectedValue(this)">
    <?php $u=$logica->provincia();
      foreach($u as $ui){
      ?>
    <option value="<?php echo $ui->id_provincia;?>"><?php echo $ui->nom_provincia;?></option>
  <?php } ?>
  </select>
                  
</div>
</div>
</div>
</div>
</div>  

<div class="field is-horizontal">
<div class="field-body">
<div class="field is-narrow">
<div class="control">
<div class="select">
     <select id="results" name="results"></select>
    </select>    
</div>
</div>
</div>
</div>
</div>

<div class="field is-horizontal">   
<div class="field-body">
<div class="field is-expanded">  
<button class="button is-success is-fullwidth" type="submit">Enviar</button>
</div>
</div>
</div>
   
</form>
</div>
</div>
</div>
</div>
<table class="table">
    <thead>
        <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Apellido</th>
            <th>Email</th>
            <th>Telefono</th>
            <th>Tipo de usuario</th>
            <th>Provincia</th>
            <th>Distrito</th>
        </tr>
    </thead>
    <tbody>
      <?php $u=$logica->selectall();
        foreach($u as $ui){ ?>
        <tr>
            <th><?php echo $ui->id_usuario;?></th>
            <td><?php echo $ui->nombre;?></td>
            <td><?php echo $ui->apellido;?></td>
            <td><?php echo $ui->email;?></td>
            <td><?php echo $ui->telefono;?></td>
            <td><?php echo $ui->nom_nivel;?> </td>
            <td><?php echo $ui->nom_provincia;?></td>
            <td><?php echo $ui->nom_distrito;?></td>

        </tr>
    </tbody>
    <?php } ?>
</table>

</section>
<footer class="footer">
<div class="content has-text-centered">
<p>
Elaborado por:Wencers Castillo
<br>
Cédula: 8-960-165
Grupo: 1LS131
</p>
</div>
</footer>
</body>
</html>